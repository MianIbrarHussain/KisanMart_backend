const express = require("express");
const http = require("http");
const socketIO = require("socket.io");
const mongo = require("mongoose");
const authRouter = require("./src/routes/authRoutes");
const homeRouter = require("./src/routes/homeRoutes");

const { UserData, ChatData } = require("./src/schemes");
const { paramsCheck } = require("./src/components/helperFunctions");

const APP = express();
const server = http.createServer(APP);
const io = socketIO(server);

APP.use("/media", express.static("./src/media"));

APP.use(
  express.urlencoded({
    extended: false,
  })
);

APP.use("/auth", authRouter);
APP.use("/home", homeRouter);

APP.post("/getMyChats", async (req, res) => {
  try {
    let check = paramsCheck(["userID"], req.body);
    if (check === true) {
      let chats = await ChatData.aggregate([
        { $match: { recipients: { $in: [req.body.userID] } } },
      ]);

      const finalData = await Promise.all(
        chats.map(async (k) => {
          let user1 = await UserData.findById(
            k.recipients[0] === req.body.userID
              ? k.recipients[1]
              : k.recipients[0]
          );
          return {
            chatID: k._id,
            recipientName: user1.name,
            profilePicture: user1.profilePicture,
            lastMessage: k.lastMessage,
          };
        })
      );

      res.status(200).json({
        success: true,
        chats: finalData,
      });
    } else return res.status(400).send(check);
  } catch (error) {
    console.log(error);
    return res.status(500).send("Internal Server Error!");
  }
});

function sendInitialChats(socket, userID) {
  ChatData.aggregate([{ $match: { recipients: { $in: [userID] } } }])
    .then((chats) => Promise.all(chats.map((k) => formatChatData(k, userID))))
    .then((finalData) => {
      socket.emit("chatUpdate", finalData);
    })
    .catch((error) => console.error("Error fetching chats:", error));
}

async function sendIndividualChats(socket, newChat) {
  const existingChat1 = await ChatData.findOne({
    recipients: { $all: [newChat.userID, newChat.recipientID] },
  });
  const existingChat2 = await ChatData.findOne({
    recipients: { $all: [newChat.recipientID, newChat.userID] },
  });
  const userData1 = await UserData.findById(newChat.recipientID);
  const userData2 = await UserData.findById(newChat.userID);

  socket.emit("newChat", {
    userID: newChat.userID,
    chatData: {
      chatID: existingChat1._id || existingChat2._id,
      recipientName: userData1.name,
      profilePicture: userData1.profilePicture,
      conversation: existingChat1.Messages || existingChat2.Messages,
    },
  });
  socket.broadcast.emit("newChat", {
    userID: newChat.recipientID,
    chatData: {
      chatID: existingChat1._id || existingChat2._id,
      recipientName: userData2.name,
      profilePicture: userData2.profilePicture,
      conversation: existingChat1.Messages || existingChat2.Messages,
    },
  });
}

async function formatChatData(k, userID) {
  let user1 = await UserData.findById(
    k.recipients[0] === userID ? k.recipients[1] : k.recipients[0]
  );
  return {
    chatID: k._id,
    recipientName: user1.name,
    profilePicture: user1.profilePicture,
    conversation: k.Messages,
    recipientID: user1._id,
  };
}

io.on("connection", (socket) => {
  // socket.join("commonRoom");
  console.log(socket.rooms);
  const userID = socket.handshake.auth.userID;
  sendInitialChats(socket, userID);

  socket.on("newMessage", async (message) => {
    console.log(socket.id);
    await handleNewMessage(message);
    socket.emit("newMessage", message);
    socket.broadcast.emit("newMessage", message);
  });

  socket.on("newChat", async (newChat) => {
    // sendInitialChats(socket, userID);
    sendIndividualChats(socket, newChat);
  });
});

async function handleNewMessage(messageData) {
  try {
    const chat = await ChatData.findById(messageData.chatID);

    if (messageData.message.isOffer) {
      chat.Messages.push({
        sender: messageData.message.sender,
        isOffer: messageData.message.isOffer,
        message: "New Offer",
        offeredPrice: messageData.message.offeredPrice,
        requiredQuantity: messageData.message.requiredQuantity,
        productID: messageData.message.productID,
        terms: messageData.message.terms,
        timestamp: new Date(),
      });
    } else {
      chat.Messages.push({
        sender: messageData.message.sender,
        isOffer: messageData.message.isOffer,
        message: messageData.message.message,
        timestamp: new Date(),
      });
    }

    await chat.save();
  } catch (error) {
    console.error("Error handling new message:", error);
    throw error;
  }
}

const PORT = process.env.PORT || 3000;
server.listen(PORT, async () => {
  try {
    mongo.connect("mongodb://0.0.0.0:27017/Kisan_Mart_BackEnd");
    console.log("ALL GOOD on " + PORT);
  } catch (error) {
    console.log("DB error=============");
  }
});
