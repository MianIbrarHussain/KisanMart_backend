const mongo = require("mongoose");

const UserRegistration = mongo.Schema({
  email: {
    type: String,
    required: true,
    unique: true,
  },
  password: {
    type: String,
    required: true,
  },
  isVerified: {
    type: Boolean,
    required: true,
  },
  name: {
    type: String,
    required: false,
  },
  phone: {
    type: String,
    required: false,
  },
  whatsapp: {
    type: String,
    required: false,
  },
  city: {
    type: String,
    required: false,
  },
  profilePicture: {
    type: String,
    required: false,
  },
  cnic: {
    type: String,
    required: false,
    unique: true,
    sparse: true,
  },
});

const Chats = mongo.Schema(
  {
    recipients: [String],
    Messages: [
      {
        sender: String,
        isOffer: Boolean,
        message: String,
        offeredPrice: String,
        requiredQuantity: String,
        productID: String,
        terms: Array,
        timestamp: Date,
      },
    ],
  },
  { timestamps: true }
);

const Products = mongo.Schema({
  productName: {
    type: String,
    required: true,
  },
  unit: {
    type: String,
    required: true,
  },
  pricePerUnit: {
    type: String,
    required: true,
  },
  region: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  terms: {
    type: String,
    required: true,
  },
  supplierID: {
    type: String,
    required: true,
  },
  quality: {
    type: Boolean,
    required: true,
  },
  offersMade: {
    type: Number,
    required: false,
    default: 0,
  },
  Category: {
    type: String,
    required: true,
  },
  productImages: [String],
});

const UserData = mongo.model("USERDATA", UserRegistration);
const ChatData = mongo.model("CHATDATA", Chats);
const ProductsData = mongo.model("PRODUCTSDATA", Products);

module.exports = { UserData, ChatData, ProductsData };
